package aima.basic;

public class Wall extends EnvironmentObject {

}