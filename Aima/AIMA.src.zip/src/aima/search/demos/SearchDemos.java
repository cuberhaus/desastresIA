
package aima.search.demos;




/**
 * @author Ravi Mohan
 *
 */
public class SearchDemos {
	public static void main(String[] args){
		NQueensDemo.main(null);
		EightPuzzleDemo.main(null);
		CSPDemo.main(null);
	}

}
